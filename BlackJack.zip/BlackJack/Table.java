import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import javax.swing.JPanel;
import java.awt.Dimension;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;

public class Table extends JPanel implements ActionListener{

    private ArrayList<Card> deck;
    private ArrayList<Card> player;
    private ArrayList<Card> dealersCards;
    private JButton hit;
    private JButton stand;
    private JButton playAgain;
    private JButton advice;
    private JButton exit;
    private Color green;
    private Color gray;
    private BufferedImage back;
    private boolean visible;
    private boolean loss;
    private boolean tie;
    private boolean win;
    private boolean help;
    private boolean gameOver;
    private boolean pressed;
    private int total;
    private int dealersTotal;
    private int winCounter;
    private int lossCounter;

	public Table() {
        loss = false;
        win = false;
        tie = false;
        pressed = false;
        lossCounter = 0;
        winCounter = 0;
        visible = true;
        gameOver = false;
        help = false;

        deck = new ArrayList<Card>();
        deck.add(new Card(2, "2", "hearts"));
        deck.add(new Card(3, "3", "hearts"));
        deck.add(new Card(4, "4", "hearts"));
        deck.add(new Card(5, "5", "hearts"));
        deck.add(new Card(6, "6", "hearts"));
        deck.add(new Card(7, "7", "hearts"));
        deck.add(new Card(8, "8", "hearts"));
        deck.add(new Card(9, "9", "hearts"));
        deck.add(new Card(10, "10", "hearts"));
        deck.add(new Card(10, "J", "hearts"));
        deck.add(new Card(10, "Q", "hearts"));
        deck.add(new Card(10, "K", "hearts"));
        deck.add(new Card(11, "A", "hearts"));
        deck.add(new Card(2, "2", "diamonds"));
        deck.add(new Card(3, "3", "diamonds"));
        deck.add(new Card(4, "4", "diamonds"));
        deck.add(new Card(5, "5", "diamonds"));
        deck.add(new Card(6, "6", "diamonds"));
        deck.add(new Card(7, "7", "diamonds"));
        deck.add(new Card(8, "8", "diamonds"));
        deck.add(new Card(9, "9", "diamonds"));
        deck.add(new Card(10, "10", "diamonds"));
        deck.add(new Card(10, "J", "diamonds"));
        deck.add(new Card(10, "Q", "diamonds"));
        deck.add(new Card(10, "K", "diamonds"));
        deck.add(new Card(11, "A", "diamonds"));
        deck.add(new Card(2, "2", "clubs"));
        deck.add(new Card(3, "3", "clubs"));
        deck.add(new Card(4, "4", "clubs"));
        deck.add(new Card(5, "5", "clubs"));
        deck.add(new Card(6, "6", "clubs"));
        deck.add(new Card(7, "7", "clubs"));
        deck.add(new Card(8, "8", "clubs"));
        deck.add(new Card(9, "9", "clubs"));
        deck.add(new Card(10, "10", "clubs"));
        deck.add(new Card(10, "J", "clubs"));
        deck.add(new Card(10, "Q", "clubs"));
        deck.add(new Card(10, "K", "clubs"));
        deck.add(new Card(11, "A", "clubs"));
        deck.add(new Card(2, "2", "spades"));
        deck.add(new Card(3, "3", "spades"));
        deck.add(new Card(4, "4", "spades"));
        deck.add(new Card(5, "5", "spades"));
        deck.add(new Card(6, "6", "spades"));
        deck.add(new Card(7, "7", "spades"));
        deck.add(new Card(8, "8", "spades"));
        deck.add(new Card(9, "9", "spades"));
        deck.add(new Card(10, "10", "spades"));
        deck.add(new Card(10, "J", "spades"));
        deck.add(new Card(10, "Q", "spades"));
        deck.add(new Card(10, "K", "spades"));
        deck.add(new Card(11, "A", "spades"));

        //call shuffle
        shuffle();

        //set player total value
        total = deck.get(0).getValue() + deck.get(1).getValue();

        //give the player cards
        player = new ArrayList<Card>();
        //get the top card from the deck and add it to the player
        player.add(deck.get(0));
        //remove the top card from the deck
        deck.remove(0);
        player.add(deck.get(0));
        deck.remove(0);

        //give the dealer cards
        dealersCards = new ArrayList<Card>();
        //get the top card from the deck and add it to the player
        dealersCards.add(deck.get(0));
        //remove the top card from the deck
        deck.remove(0);
        dealersCards.add(deck.get(0));
        deck.remove(0);

        //set dealers total
        dealersTotal = 0;
        for(int i=0; i<dealersCards.size(); i++){
            dealersTotal += dealersCards.get(i).getValue();
        }

        //create a hit button
        //don't forget to setLayout(null); and setFocusable(true);
        setLayout(null);
        setFocusable(true);
        
        // when pressed, add a card from the deck to the player
        hit = new JButton("Hit");
        hit.setBounds(75,525, 100, 30); //sets the location and size
        hit.addActionListener(this); //add the listener
        this.add(hit); //add to JPanel

        //stand button
        stand = new JButton("Stand");
        stand.setBounds(175,525, 100, 30); //sets the location and size
        stand.addActionListener(this); //add the listener
        this.add(stand); //add to JPanel

        //advice button
        advice = new JButton("Advice");
        advice.setBounds(650,525, 100, 30); //sets the location and size
        advice.addActionListener(this); //add the listener
        this.add(advice); //add to JPanel

        //x button
        exit = new JButton("X");
        exit.setBounds(505,235, 15, 15); //sets the location and size
        exit.addActionListener(this); //add the listener
        this.add(exit); //add to JPanel
        exit.setVisible(false);

        //new game button
        playAgain = new JButton("New Game");
        playAgain.setBounds(350,290, 100, 30); //sets the location and size
        playAgain.addActionListener(this); //add the listener
        this.add(playAgain); //add to JPanel
        playAgain.setVisible(false);

        try{
            back = ImageIO.read(new File("back_card.png"));
        } catch (IOException e) {
            System.out.println(e);
        }
    
    }
	
	public Dimension getPreferredSize() {
		//Sets the size of the panel
		return new Dimension(800,600);
	}

	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		green = new Color(34, 94, 38);
		g.setColor(green);
		g.fillRect(0,0,800,600);

        //draw each of the players cards
        int x = 20;
        int y = 350;
        for(int i=0; i<player.size(); i++){
            player.get(i).drawMe(g, x, y);
            x+=100;
        }

        //draw the first dealer card
        int x2 = 20;
        int y2 = 100;
        for(int i=0; i<1; i++){
            dealersCards.get(i).drawMe(g, x2, y2);
            x2+=100;
        }

        //draw back of card
        if(visible == true){
            g.drawImage(back, x2-102, y2-2, null);
        }

        //draw the rest of the dealers cards
        for(int i=0; i<dealersCards.size()-1; i++){
            dealersCards.get(i+1).drawMe(g, x2, y2);
            x2+=100;
        }


        //display total
        g.setColor(Color.BLACK);
        Font font = new Font("Arial", Font.PLAIN, 20);
        g.setFont(font);
        g.drawString("Total Card Value: " + total, 530, 400);
        if(visible == true){
            g.drawString("Dealer's Total Card Value: " + dealersCards.get(1).getValue(), 530, 150);
        } else {
            g.drawString("Dealer's Total Card Value: " + dealersTotal, 530, 150);
        }

        //advice screen pops up
        if(help == true && gameOver == false){
            adviceScreen(g);
        }

        //x button
        if(help == true){
            exit.setVisible(true);
        } else if(help == false){
            exit.setVisible(false);
        }

        //player loses
        if(loss == true){
            losingScreen(g);
        }

        //player ties
        if(tie == true){
            tiedScreen(g);
        }

        //player wins
        if(win == true){
            winningScreen(g);
        }

        g.drawString("Player wins: " + winCounter, 530, 430);
        g.drawString("Dealer wins: " + lossCounter, 530, 180);

        //play again button
        if(gameOver == true){
            playAgain.setVisible(true);
        }
	}
	


	public void shuffle(){
		//write code to shuffle your deck
        for(int i=0; i<deck.size(); i++){
            //Swap with a random index
            int j = (int)(Math.random()*deck.size());
 
 
            Card temp1 = deck.get(i);
            Card temp2 = deck.get(j);
            deck.set(i, temp2);
            deck.set(j, temp1);
        }
	}
    
    public void losingScreen(Graphics g){
        g.setColor(Color.BLACK);
        g.fillRect(340, 235, 120, 100);
        g.setColor(Color.WHITE);
        g.fillRect(350, 245, 100, 80);
        g.setColor(Color.BLACK);
        Font font = new Font("Arial", Font.PLAIN, 20);
        g.setFont(font);
        g.drawString("You Lost", 360, 275);
        gameOver = true;
    }

    public void winningScreen(Graphics g){
        g.setColor(Color.BLACK);
        g.fillRect(340, 235, 120, 100);
        g.setColor(Color.WHITE);
        g.fillRect(350, 245, 100, 80);
        g.setColor(Color.BLACK);
        Font font = new Font("Arial", Font.PLAIN, 20);
        g.setFont(font);
        g.drawString("You Won", 360, 275);
        gameOver = true;
    }

    public void tiedScreen(Graphics g){
        g.setColor(Color.BLACK);
        g.fillRect(340, 235, 120, 100);
        g.setColor(Color.WHITE);
        g.fillRect(350, 245, 100, 80);
        g.setColor(Color.BLACK);
        Font font = new Font("Arial", Font.PLAIN, 20);
        g.setFont(font);
        g.drawString("You Tied", 360, 275);
        gameOver = true;
    }

    public void adviceScreen(Graphics g){
        gray = new Color(171, 168, 161);
        g.setColor(gray);
        g.fillRect(300, 235, 220, 100);
        g.setColor(Color.WHITE);
        g.fillRect(310, 245, 200, 80);
        g.setColor(Color.BLACK);
        Font font = new Font("Arial", Font.PLAIN, 20);
        g.setFont(font);
        g.drawString("Advice", 380, 275);
        g.drawString("______", 377, 278);
        if(total >= 17){
            g.drawString("You should stand", 332, 305);
        } else if(total < 17){
            g.drawString("You should hit", 345, 305);
        }
    }

    public void actionPerformed(ActionEvent e) {
        if(total < 21 && pressed == false){
            if (e.getSource() == hit) {
                total = 0;

                player.add(deck.get(0));
                deck.remove(0);
        
                for(int i=0; i<player.size(); i++){
                    total += player.get(i).getValue();
                }

                if(total > 21){
                    loss = true;
                    lossCounter++;
                } 
                repaint();
            }
        }
        
        if(total <= 21 && pressed == false){
            if (e.getSource() == stand) {
                visible = false;

                while(dealersTotal < 17){
                    dealersCards.add(deck.get(0));
                    deck.remove(0);

                    dealersTotal = 0;
                    for(int i=0; i<dealersCards.size(); i++){
                        dealersTotal += dealersCards.get(i).getValue();
                    }
                }

                if(dealersTotal <= 21 && dealersTotal > total){
                    loss = true;
                    lossCounter++;
                } else if(dealersTotal == total){
                    tie = true;
                } else if(total <= 21 && total > dealersTotal){
                    win = true;
                    winCounter++;
                } else if(total <=21 && dealersTotal > 21){
                    win = true;
                    winCounter++;
                }

                pressed = true;

                repaint();
            }
        }

        if(gameOver == true){
            if (e.getSource() == playAgain) {
                for(int i = 0; i < player.size(); i++){
                    deck.add(player.get(i));
                    player.remove(i);
                    i--;
                }
                for(int i = 0; i < dealersCards.size(); i++){
                    deck.add(dealersCards.get(i));
                    dealersCards.remove(i);
                    i--;
                }
                
                shuffle();
                
                //give the player cards
                //get the top card from the deck and add it to the player
                player.add(deck.get(0));
                //remove the top card from the deck
                deck.remove(0);
                player.add(deck.get(0));
                deck.remove(0);
    
                //give the dealer cards
                //get the top card from the deck and add it to the player
                dealersCards.add(deck.get(0));
                //remove the top card from the deck
                deck.remove(0);
                dealersCards.add(deck.get(0));
                deck.remove(0);
                
                /* 
                if(loss == true){
                    lossCounter -=4;
                }
                */
                visible = true;
                gameOver = false;
                pressed = false;
                win = false;
                loss = false;
                tie = false;
                playAgain.setVisible(false);
                
                //set total value
                total = 0;
                total = player.get(0).getValue() + player.get(1).getValue();
                
                //set dealers total
                dealersTotal = 0;
                for(int i=0; i<dealersCards.size(); i++){
                    dealersTotal += dealersCards.get(i).getValue();
                }
                repaint();
            }
        }
        if (e.getSource() == advice) {
            help = true;
            repaint();
        }
        if (e.getSource() == exit) {
            help = false;
            repaint();
        }
        
    }


}